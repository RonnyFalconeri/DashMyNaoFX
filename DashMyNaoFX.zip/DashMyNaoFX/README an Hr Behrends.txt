
*** TIF17A - Informatik-Labor Semester 1, Februar 2018 ***

Informationen zur Abgabe des Projekts für Herr Behrends.


    Projekt: Dashboard für NAO

    Projektmitglieder: Ronny Falconeri, Marcel Uthe, Niclas Meier

    Programmname: DashMyNaoFX

    Version Control: Das Repository "DashMyNaoFX" wurde auf GitHub hochgeladen und bearbeitet. Nutzer: RonnyFalconeri


-   Die Leistung der jeweiligen Gruppenmitglieder sollte nicht über die Git-Historie beurteilt werden.
    Diese gibt nämlich keine Auskunft darüber, wieviel wer getan hat. Viele Commits waren lediglich kleine Änderungen.

-   Unsere kleine Dokumentation "DashMyNaoFX - Features.pdf" listet alle Funktionen auf, unterteilt in "Must-Haves"
    und "Nice-To-Haves". Diese ist in englisch verfasst, da dieses Projekt auf GitHub als OpenSource-Programm
    veröffentlicht werden soll.


